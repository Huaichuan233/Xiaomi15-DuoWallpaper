# Xiaomi 15 Duo Wallpaper v3

Phone-deployable Android live wallpaper inspired by the iPhone Duo visual effect.

## v3 fixes
- Selected photos are copied into app-private storage immediately after selection, avoiding OEM picker URI permission issues.
- Wallpaper rendering falls back to the original image if RuntimeShader is rejected by an OEM GPU driver, preventing a black screen.
- The original sensor-driven Duo spatial projection remains enabled when the shader is supported.

## Usage
1. Open the app.
2. Tap “选择一张照片作为壁纸”.
3. Pick a photo.
4. Tap “设置 Duo 动态壁纸”.
5. Apply it from the system wallpaper picker.
