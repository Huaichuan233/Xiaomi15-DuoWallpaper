package com.example.duowallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "Xiaomi 15 Duo Wallpaper v4\n\n传感器驱动的液态玻璃折叠壁纸"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "渲染诊断：请选择测试模式"
            textSize = 14f
            gravity = Gravity.CENTER
        }
        val choose = Button(this).apply {
            text = "选择一张照片作为壁纸"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, REQUEST_IMAGE)
            }
        }
        val testSimple = Button(this).apply {
            text = "测试 AGSL（简单模式）"
            setOnClickListener {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_RENDER_MODE, RENDER_SIMPLE).apply()
                status.text = "已切换：AGSL 简单模式。重新设置一次动态壁纸后观察。"
            }
        }
        val setDuo = Button(this).apply {
            text = "启用 Duo 折叠模式"
            setOnClickListener {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_RENDER_MODE, RENDER_DUO).apply()
                status.text = "已切换：Duo 折叠模式。重新设置一次动态壁纸后观察。"
            }
        }
        val raw = Button(this).apply {
            text = "纯图片模式（基准）"
            setOnClickListener {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_RENDER_MODE, RENDER_RAW).apply()
                status.text = "已切换：纯图片模式。"
            }
        }
        val set = Button(this).apply {
            text = "设置 Duo 动态壁纸"
            setOnClickListener {
                val component = ComponentName(this@MainActivity, DuoWallpaperService::class.java)
                startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
                })
            }
        }
        val preview = Button(this).apply {
            text = "打开系统动态壁纸预览"
            setOnClickListener {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            }
        }
        val help = TextView(this).apply {
            text = "\n使用方法：选择照片 → 设置动态壁纸 → 在系统预览中应用。\n\nSensor 模式会根据手机转动产生虚拟折叠。最大角度默认 45°，为控制功耗默认 60 FPS。v4 增加 AGSL 兼容性诊断与图片采样。"
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(choose, LinearLayout.LayoutParams(-1, -2))
        root.addView(testSimple, LinearLayout.LayoutParams(-1, -2))
        root.addView(setDuo, LinearLayout.LayoutParams(-1, -2))
        root.addView(raw, LinearLayout.LayoutParams(-1, -2))
        root.addView(status)
        root.addView(set, LinearLayout.LayoutParams(-1, -2))
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        root.addView(help)
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) { }
                // Copy the selected image into app-private storage immediately.
                // This avoids wallpaper-service failures caused by revoked/non-persistable
                // picker URI permissions on some OEM ROMs.
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(File(filesDir, IMAGE_FILE)).use { output ->
                        input.copyTo(output)
                    }
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(KEY_FILE, File(filesDir, IMAGE_FILE).absolutePath)
                        .putString(KEY_URI, uri.toString())
                        .apply()
                }
            }
        }
    }

    companion object {
        const val PREFS = "duo_wallpaper"
        const val KEY_URI = "image_uri"
        const val KEY_FILE = "image_file"
        const val IMAGE_FILE = "selected_wallpaper.jpg"
        const val KEY_RENDER_MODE = "render_mode"
        const val RENDER_DUO = 0
        const val RENDER_SIMPLE = 1
        const val RENDER_RAW = 2
        private const val REQUEST_IMAGE = 1001
    }
}
