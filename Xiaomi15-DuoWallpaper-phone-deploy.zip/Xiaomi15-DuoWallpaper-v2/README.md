# Xiaomi 15 Duo Wallpaper v2

这是第二阶段的可落地版本：把 Duo-Fold AGSL 视觉效果放进 Android `WallpaperService`，用于普通直板手机。

## 功能
- Xiaomi 15 / Android 13+ 目标
- 选择照片作为动态壁纸素材
- Sensor 模式：陀螺仪/Rotation Vector → 虚拟折叠角度
- 最大折叠角 45°
- 60 FPS 默认渲染，避免持续 120 FPS 带来的额外耗电
- AGSL RuntimeShader：透视投影 + 间隙模糊 + 暗化
- 无 root、无无障碍权限、无系统级修改

## 编译
1. Android Studio 打开本目录。
2. 安装 Android SDK 35。
3. Gradle JDK 使用 17。
4. Sync Project。
5. 连接 Xiaomi 15，Run。
6. App 中选择照片 → 设置 Duo 动态壁纸。

原始项目使用 Android 13+ `RuntimeShader`，本项目将同一类 AGSL 效果迁移到 `WallpaperService.Engine` 的 Canvas 渲染路径。

## 注意
普通动态壁纸只能控制壁纸本身，不能让 HyperOS 桌面图标、通知栏和第三方 App 一起发生空间折叠。要做到后者，需要 Launcher/SystemUI 级支持。
