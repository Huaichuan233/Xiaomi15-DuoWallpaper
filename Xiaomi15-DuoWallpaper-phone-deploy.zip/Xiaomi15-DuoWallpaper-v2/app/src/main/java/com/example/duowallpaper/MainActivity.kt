package com.example.duowallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "Xiaomi 15 Duo Wallpaper v2\n\n传感器驱动的液态玻璃折叠壁纸"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val choose = Button(this).apply {
            text = "选择一张照片作为壁纸"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, REQUEST_IMAGE)
            }
        }
        val set = Button(this).apply {
            text = "设置 Duo 动态壁纸"
            setOnClickListener {
                val component = ComponentName(this@MainActivity, DuoWallpaperService::class.java)
                startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
                })
            }
        }
        val preview = Button(this).apply {
            text = "打开系统动态壁纸预览"
            setOnClickListener {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            }
        }
        val help = TextView(this).apply {
            text = "\n使用方法：选择照片 → 设置动态壁纸 → 在系统预览中应用。\n\nSensor 模式会根据手机转动产生虚拟折叠。最大角度默认 45°，为控制功耗默认 60 FPS。"
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(choose, LinearLayout.LayoutParams(-1, -2))
        root.addView(set, LinearLayout.LayoutParams(-1, -2))
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        root.addView(help)
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) { }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URI, uri.toString()).apply()
            }
        }
    }

    companion object {
        const val PREFS = "duo_wallpaper"
        const val KEY_URI = "image_uri"
        private const val REQUEST_IMAGE = 1001
    }
}
