package com.example.duowallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class DuoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DuoEngine()

    inner class DuoEngine : Engine(), SensorEventListener {
        private val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        private val rotation = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        private val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var bitmap: Bitmap? = null
        private var shader: RuntimeShader? = null
        private var contentShader: BitmapShader? = null
        private var width = 0f
        private var height = 0f
        private var tilt = 0f
        private var targetTilt = 0f
        private var visible = false
        private var rendering = false
        private var lastTime = 0L
        private val matrix = Matrix()
        private var lastSensorTilt = 0f
        private var calibrated = false
        private var reference = 0f

        private val shaderSource = """
            uniform shader content;
            uniform float2 resolution;
            uniform float tiltDegrees;
            uniform float eyeDistancePx;
            uniform float hingeSide;
            uniform float blurSpread;
            uniform float darkening;
            const float GOLDEN_ANGLE = 2.3999632297;
            const float TWO_PI = 6.2831853072;
            half4 main(float2 fragCoord) {
                float2 size = resolution;
                float tiltRad = radians(clamp(abs(tiltDegrees), 0.0, 45.0));
                if (tiltRad < 0.00001) return content.eval(fragCoord);
                float isRight = step(0.0, hingeSide);
                float hingeX = mix(0.0, size.x, isRight);
                float side = mix(1.0, -1.0, isRight);
                float d = abs(fragCoord.x - hingeX);
                float2 glass = float2(hingeX + side * d * cos(tiltRad), fragCoord.y);
                float gap = d * sin(tiltRad);
                float2 eye = size * 0.5;
                float depth = eyeDistancePx - gap;
                if (depth <= 1.0) return half4(0.0,0.0,0.0,1.0);
                float t = eyeDistancePx / depth;
                float2 hit = eye + (glass-eye)*t;
                float radius = blurSpread * gap;
                float atten = max(1.0-darkening*radius,0.0);
                if (radius < 0.5) return content.eval(hit)*half(atten);
                float tapsF = clamp(radius*2.0,6.0,24.0);
                float rotation = fract(sin(dot(fragCoord,float2(12.9898,78.233)))*43758.5453)*TWO_PI;
                half3 sum=half3(0.0); float wsum=0.0;
                for(int i=0;i<24;i++){
                    float fi=float(i); float w=1.0-step(tapsF,fi);
                    float r=radius*sqrt((fi+0.5)/tapsF);
                    float a=fi*GOLDEN_ANGLE+rotation;
                    sum += content.eval(hit+r*float2(cos(a),sin(a))).rgb*half(w);
                    wsum += w;
                }
                return half4((sum/half(max(wsum,1.0)))*half(atten),1.0);
            }
        """.trimIndent()

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            width = w.toFloat(); height = h.toFloat()
            rebuildSource()
            drawFrame()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                registerSensors()
                drawFrame()
            } else {
                unregisterSensors()
                stopLoop()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            stopLoop()
            unregisterSensors()
            super.onSurfaceDestroyed(holder)
        }

        private fun registerSensors() {
            rotation?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            gyro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
        private fun unregisterSensors() { sensorManager.unregisterListener(this) }

        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type != Sensor.TYPE_GAME_ROTATION_VECTOR && event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
            val r = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(r, event.values)
            val measured = Math.toDegrees(atan2(r[2].toDouble(), r[8].toDouble())).toFloat()
            if (!calibrated) { reference = measured; calibrated = true }
            val relative = measured - reference
            targetTilt = smoothAngle(relative.coerceIn(-45f,45f))
            lastSensorTilt = targetTilt
            if (visible) startLoop()
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

        private fun smoothAngle(value: Float): Float = value * 0.82f + tilt * 0.18f

        private fun rebuildSource() {
            bitmap?.recycle(); bitmap = null
            val uriString = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.KEY_URI, null)
            bitmap = if (uriString != null) decodeUri(Uri.parse(uriString)) else makeFallbackBitmap()
            bitmap?.let { src ->
                contentShader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                matrix.reset()
                val sx = width / src.width.toFloat(); val sy = height / src.height.toFloat()
                val scale = max(sx, sy)
                matrix.setScale(scale, scale)
                matrix.postTranslate((width-src.width*scale)/2f, (height-src.height*scale)/2f)
                contentShader?.setLocalMatrix(matrix)
            }
            if (Build.VERSION.SDK_INT >= 33) shader = RuntimeShader(shaderSource)
        }

        private fun decodeUri(uri: Uri): Bitmap? = try {
            contentResolver.openInputStream(uri).use { input: InputStream? -> BitmapFactory.decodeStream(input) }
        } catch (_: Exception) { null }

        private fun makeFallbackBitmap(): Bitmap {
            val w=1080; val h=1920
            val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val c=Canvas(b)
            val p=Paint(); p.shader=android.graphics.LinearGradient(0f,0f,w.toFloat(),h.toFloat(),Color.rgb(20,30,50),Color.rgb(8,10,18),Shader.TileMode.CLAMP); c.drawRect(0f,0f,w.toFloat(),h.toFloat(),p); return b
        }

        private fun drawFrame() {
            val holder=surfaceHolder
            if (!visible || width<=1 || height<=1) return
            val c=try { holder.lockCanvas() } catch (_: Exception) { null } ?: return
            try {
                c.drawColor(Color.BLACK)
                val src=contentShader ?: return
                if (Build.VERSION.SDK_INT >= 33) {
                    val rs=shader ?: RuntimeShader(shaderSource).also { shader=it }
                    rs.setInputShader("content", src)
                    rs.setFloatUniform("resolution",width,height)
                    rs.setFloatUniform("tiltDegrees",tilt)
                    rs.setFloatUniform("eyeDistancePx",450f*(width/1080f))
                    rs.setFloatUniform("hingeSide",if(tilt>=0f)1f else -1f)
                    rs.setFloatUniform("blurSpread",0.12f)
                    rs.setFloatUniform("darkening",0.015f*6f/max(width/1080f,0.1f))
                    paint.shader=rs
                    c.drawRect(0f,0f,width,height,paint)
                    paint.shader=null
                } else {
                    paint.shader=src; c.drawRect(0f,0f,width,height,paint); paint.shader=null
                }
            } finally { holder.unlockCanvasAndPost(c) }
        }

        private fun startLoop() {
            if (rendering) return
            rendering=true
            lastTime=System.nanoTime()
            mainHandler.post(frameRunnable)
        }
        private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        private val frameRunnable = object: Runnable {
            override fun run() {
                if (!rendering || !visible) return
                val now=System.nanoTime(); val dt=((now-lastTime)/1e9).toFloat().coerceAtMost(0.05f); lastTime=now
                val alpha=min(1f,dt*10f)
                tilt += (targetTilt-tilt)*alpha
                drawFrame()
                mainHandler.postDelayed(this,16L)
            }
        }
        private fun stopLoop(){ rendering=false; mainHandler.removeCallbacks(frameRunnable) }
    }
}
